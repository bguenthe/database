create view finanzstatus_monthly(id, monat, vermoegen) as
WITH summary AS (
    SELECT p.id,
           p.kontostand,
           to_char(p.datum::timestamp with time zone, 'YYYYMM'::text)                                                                            AS monat,
           row_number()
           OVER (PARTITION BY p.institut, p.typ, (to_char(p.datum::timestamp with time zone, 'YYYYMM'::text)) ORDER BY p.timestampinserted DESC) AS rk
    FROM finanzstatus p
)
SELECT row_number() OVER () AS id,
       s.monat,
       sum(s.kontostand)    AS vermoegen
FROM summary s
WHERE s.rk = 1
GROUP BY s.monat
ORDER BY s.monat;

alter table finanzstatus_monthly
    owner to finanzstatus;

