create view umsatz_uebersicht(monat, "Posten", "Einkuenfte", "Kosten") as
SELECT to_char(umsaetze.wertstellungstag::timestamp with time zone, 'YYYYMM'::text) AS monat,
       CASE
           WHEN lower(umsaetze.buchungsdetails) ~~ '%edeka%'::text OR
                lower(umsaetze.buchungsdetails) ~~ '%e-center%'::text OR
                lower(umsaetze.buchungsdetails) ~~ '%lidl%'::text OR
                lower(umsaetze.buchungsdetails) ~~ '%aldi%'::text OR
                lower(umsaetze.buchungsdetails) ~~ '%hayungas%'::text OR
                lower(umsaetze.buchungsdetails) ~~ '%famila%'::text OR
                lower(umsaetze.buchungsdetails) ~~ '%real%'::text OR lower(umsaetze.buchungsdetails) ~~ '%rewe%'::text
               THEN 'LBM'::text
           WHEN lower(umsaetze.buchungsdetails) ~~ '%haspa%'::text AND umsaetze.betrag < 0::numeric OR
                lower(umsaetze.buchungsdetails) ~~ '%voba%'::text AND umsaetze.betrag < 0::numeric OR
                lower(umsaetze.buchungsdetails) ~~ '%commerzbank%'::text AND umsaetze.betrag < 0::numeric OR
                lower(umsaetze.buchungsdetails) ~~ '%commerzbank%'::text AND umsaetze.betrag < 0::numeric
               THEN 'Geld abheben'::text
           WHEN lower(umsaetze.buchungsdetails) ~~ '%verwendungszweck bezuege%'::text THEN 'Gehalt'::text
           WHEN lower(umsaetze.buchungsdetails) ~~ '%spotify%'::text THEN 'Spotify'::text
           WHEN lower(umsaetze.buchungsdetails) ~~ '%smar tmobil.de%'::text THEN 'Handy'::text
           WHEN lower(umsaetze.buchungsdetails) ~~ '%amazon%'::text THEN 'Amazon'::text
           WHEN lower(umsaetze.umsatzart) ~~ '%zinsen/entgelt%'::text THEN 'Kontoführung'::text
           WHEN lower(umsaetze.buchungsdetails) ~~ '%aypal%'::text AND
                NOT lower(umsaetze.buchungsdetails) ~~ '%spotify%'::text THEN 'paypal'::text
           WHEN umsaetze.buchungsdetails ~~ '%ABSCHLAG Gas%'::text THEN 'Gas'::text
           WHEN umsaetze.buchungsdetails ~~ '%HAMBURG ENERGIE%'::text THEN 'Strom'::text
           WHEN umsaetze.buchungsdetails ~~ '%WILHELM.TEL%'::text THEN 'WILHELM.TEL'::text
           WHEN umsaetze.buchungsdetails ~~ '%LS0310000899393%'::text THEN 'Stadtwerke Abwasser'::text
           WHEN umsaetze.buchungsdetails ~~ '%004182867288%'::text THEN '1&1'::text
           ELSE umsaetze.buchungsdetails
           END                                                                      AS "Posten",
       sum(
               CASE
                   WHEN umsaetze.betrag > 0::numeric THEN umsaetze.betrag
                   ELSE NULL::numeric
                   END)                                                             AS "Einkuenfte",
       sum(
               CASE
                   WHEN umsaetze.betrag < 0::numeric THEN umsaetze.betrag * '-1'::integer::numeric
                   ELSE NULL::numeric
                   END)                                                             AS "Kosten"
FROM umsaetze
GROUP BY (to_char(umsaetze.wertstellungstag::timestamp with time zone, 'YYYYMM'::text)),
         (
             CASE
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%edeka%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%e-center%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%lidl%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%aldi%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%hayungas%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%famila%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%real%'::text OR lower(umsaetze.buchungsdetails) ~~ '%rewe%'::text
                     THEN 'LBM'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%haspa%'::text AND umsaetze.betrag < 0::numeric OR
                      lower(umsaetze.buchungsdetails) ~~ '%voba%'::text AND umsaetze.betrag < 0::numeric OR
                      lower(umsaetze.buchungsdetails) ~~ '%commerzbank%'::text AND umsaetze.betrag < 0::numeric OR
                      lower(umsaetze.buchungsdetails) ~~ '%commerzbank%'::text AND umsaetze.betrag < 0::numeric
                     THEN 'Geld abheben'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%verwendungszweck bezuege%'::text THEN 'Gehalt'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%spotify%'::text THEN 'Spotify'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%smar tmobil.de%'::text THEN 'Handy'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%amazon%'::text THEN 'Amazon'::text
                 WHEN lower(umsaetze.umsatzart) ~~ '%zinsen/entgelt%'::text THEN 'Kontoführung'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%aypal%'::text AND
                      NOT lower(umsaetze.buchungsdetails) ~~ '%spotify%'::text THEN 'paypal'::text
                 WHEN umsaetze.buchungsdetails ~~ '%ABSCHLAG Gas%'::text THEN 'Gas'::text
                 WHEN umsaetze.buchungsdetails ~~ '%HAMBURG ENERGIE%'::text THEN 'Strom'::text
                 WHEN umsaetze.buchungsdetails ~~ '%WILHELM.TEL%'::text THEN 'WILHELM.TEL'::text
                 WHEN umsaetze.buchungsdetails ~~ '%LS0310000899393%'::text THEN 'Stadtwerke Abwasser'::text
                 WHEN umsaetze.buchungsdetails ~~ '%004182867288%'::text THEN '1&1'::text
                 ELSE umsaetze.buchungsdetails
                 END)
ORDER BY (to_char(umsaetze.wertstellungstag::timestamp with time zone, 'YYYYMM'::text)),
         (
             CASE
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%edeka%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%e-center%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%lidl%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%aldi%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%hayungas%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%famila%'::text OR
                      lower(umsaetze.buchungsdetails) ~~ '%real%'::text OR lower(umsaetze.buchungsdetails) ~~ '%rewe%'::text
                     THEN 'LBM'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%haspa%'::text AND umsaetze.betrag < 0::numeric OR
                      lower(umsaetze.buchungsdetails) ~~ '%voba%'::text AND umsaetze.betrag < 0::numeric OR
                      lower(umsaetze.buchungsdetails) ~~ '%commerzbank%'::text AND umsaetze.betrag < 0::numeric OR
                      lower(umsaetze.buchungsdetails) ~~ '%commerzbank%'::text AND umsaetze.betrag < 0::numeric
                     THEN 'Geld abheben'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%verwendungszweck bezuege%'::text THEN 'Gehalt'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%spotify%'::text THEN 'Spotify'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%smar tmobil.de%'::text THEN 'Handy'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%amazon%'::text THEN 'Amazon'::text
                 WHEN lower(umsaetze.umsatzart) ~~ '%zinsen/entgelt%'::text THEN 'Kontoführung'::text
                 WHEN lower(umsaetze.buchungsdetails) ~~ '%aypal%'::text AND
                      NOT lower(umsaetze.buchungsdetails) ~~ '%spotify%'::text THEN 'paypal'::text
                 WHEN umsaetze.buchungsdetails ~~ '%ABSCHLAG Gas%'::text THEN 'Gas'::text
                 WHEN umsaetze.buchungsdetails ~~ '%HAMBURG ENERGIE%'::text THEN 'Strom'::text
                 WHEN umsaetze.buchungsdetails ~~ '%WILHELM.TEL%'::text THEN 'WILHELM.TEL'::text
                 WHEN umsaetze.buchungsdetails ~~ '%LS0310000899393%'::text THEN 'Stadtwerke Abwasser'::text
                 WHEN umsaetze.buchungsdetails ~~ '%004182867288%'::text THEN '1&1'::text
                 ELSE umsaetze.buchungsdetails
                 END);

alter table umsatz_uebersicht
    owner to finanzstatus;

