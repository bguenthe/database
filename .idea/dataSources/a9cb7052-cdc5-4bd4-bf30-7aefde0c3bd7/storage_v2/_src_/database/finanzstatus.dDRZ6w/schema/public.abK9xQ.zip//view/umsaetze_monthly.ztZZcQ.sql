create view umsaetze_monthly(id, monat, einkuenfte, kosten) as
SELECT row_number() OVER ()                                                         AS id,
       to_char(umsaetze.wertstellungstag::timestamp with time zone, 'YYYYMM'::text) AS monat,
       sum(
               CASE
                   WHEN umsaetze.betrag > 0::numeric THEN umsaetze.betrag
                   ELSE NULL::numeric
                   END)                                                             AS einkuenfte,
       sum(
               CASE
                   WHEN umsaetze.betrag < 0::numeric THEN umsaetze.betrag
                   ELSE NULL::numeric
                   END) * '-1'::integer::numeric                                    AS kosten
FROM umsaetze
GROUP BY (to_char(umsaetze.wertstellungstag::timestamp with time zone, 'YYYYMM'::text))
ORDER BY (to_char(umsaetze.wertstellungstag::timestamp with time zone, 'YYYYMM'::text));

alter table umsaetze_monthly
    owner to finanzstatus;

